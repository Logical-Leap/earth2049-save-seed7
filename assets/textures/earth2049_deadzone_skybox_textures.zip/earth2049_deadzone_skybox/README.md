# Earth 2049 Dead Zone Skybox

## Three.js cubemap order

```js
const skybox = new THREE.CubeTextureLoader().load([
  'earth2049_deadzone_px.png',
  'earth2049_deadzone_nx.png',
  'earth2049_deadzone_py.png',
  'earth2049_deadzone_ny.png',
  'earth2049_deadzone_pz.png',
  'earth2049_deadzone_nz.png'
]);

skybox.colorSpace = THREE.SRGBColorSpace;
scene.background = skybox;
```

The folder also includes a 2:1 equirectangular version for sphere-based backgrounds.
